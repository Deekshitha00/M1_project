## Architecture

![Architecture Diagram](https://user-images.githubusercontent.com/89658708/132314162-500b4411-ced0-4558-9229-6d27d5ddb920.png)




## Flow Chart

![flow](https://user-images.githubusercontent.com/89658708/132314252-2f83e306-78bc-4ef4-b13d-43a4677ec441.png)

