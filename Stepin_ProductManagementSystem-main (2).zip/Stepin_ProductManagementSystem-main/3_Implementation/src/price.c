/**
 * @file price.c
 * @author Aditi Iyer
 * @brief 
 * @version 0.1
 * @date 2021-09-08
 * 
 * @copyright Copyright (c) 2021
 * 
 */

#include "op.h"

int price()
{
	int sum=1000;
	if(sum==1000)
	{
		return 1;
	}
	else
	{
	return 0;
	}
}
		