# Stepin_ProductManagementSystem

* Cosmetic Product Management system is simple application to manage Cosmetic product details and perform CRUD operations.

* Cosmetic Products can be added, deleted and viewed.
