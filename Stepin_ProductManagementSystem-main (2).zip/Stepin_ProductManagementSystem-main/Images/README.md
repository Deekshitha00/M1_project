# Images 

## OutPut Images

### Welcome Page

![Welcome](https://user-images.githubusercontent.com/89658708/132327920-eefcc676-b0bb-4b43-8fb6-dd109a7e74ce.png)


### Add cosmetic products

#### Invalid Product name and company

![Invalid add](https://user-images.githubusercontent.com/89658708/132328002-06b85d7a-8b2e-4f6e-b2de-5c13f67f24d4.png)


#### Valid Product name and company, Products added successfully

![Add](https://user-images.githubusercontent.com/89658708/132328116-76bf7f47-c552-4558-baf4-8446facae479.png)

### Delete Products

![del1](https://user-images.githubusercontent.com/89658708/132328455-8792a7c0-c624-42e5-aed8-d9b3459df901.png)
![del2](https://user-images.githubusercontent.com/89658708/132328463-facdcdad-a5e2-472e-9d52-e6e04f2a1fe0.png)

#### Products not found to delete

![del not found](https://user-images.githubusercontent.com/89658708/132328511-debee443-3b12-47e2-983c-d3448963dad5.png)


### View Cosmetic Products

![view](https://user-images.githubusercontent.com/89658708/132328729-3682ae2b-1e3f-4f70-a6cc-0fcb2c15a230.png)


### Edit Cosmetic Products

#### Edit when products are found

![edit1](https://user-images.githubusercontent.com/89658708/132328846-9b451549-c68b-4249-8685-63150e1d3dce.png)

#### Products are edited successfully

![edit2](https://user-images.githubusercontent.com/89658708/132328864-1b0434a3-1cbe-4cce-b5a8-a13e527a4253.png)

#### Product not found to edit

![edit not found](https://user-images.githubusercontent.com/89658708/132329145-1fba89d5-8fb9-45ce-8af9-69aab96c37da.png)

